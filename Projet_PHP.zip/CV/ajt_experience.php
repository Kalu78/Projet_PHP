<?php include("inc/header.inc.php"); ?>
<?php include("inc/data.inc.php"); ?>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top" id="sideNav">
</nav>

<h2 class="xp">Experience</h2>


  <form id="form" action="" method="POST">
    <div class="form-group">
      <label for="exampleInputEmail1" class="name">Poste :</label>
      <input type="text" name="Poste" id="Poste" class="form-control"  aria-describedby="emailHelp">
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Société : </label>
      <input type="text" name="Societe" class="form-control" id="Societe" aria-describedby="emailHelp">
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Année(s) : </label>
      <input type="text" name="Dates" class="form-control" id="Dates" aria-describedby="emailHelp">
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Résumé : </label>
      <textarea type="text" name="Résume" class="form-control" id="Résume" aria-describedby="emailHelp"></textarea>
    </div>
    <div class="btn_ajt">
      <button type="submit" form="form" class="btn btn-light">Ajouter</button>
    </div>
  </form>


<?php
  if (!empty ($_POST)){
    $poste = $_POST['Poste'];
    $date = $_POST['Dates'];
    $societe = $_POST['Societe'];
    $resume = $_POST['Résume'];
    if (!empty($poste) AND !empty($date) AND !empty($societe) AND !empty($resume))
    {
      $sql = "INSERT INTO experience (Poste, Dates, Societe, Résume) VALUES ('$poste', '$date', '$societe', '$resume');";
      $result = $pdo->exec($sql);
      echo "Données enregistrées.";
    }
    else{
      echo "Erreur";
    }
  }

?>