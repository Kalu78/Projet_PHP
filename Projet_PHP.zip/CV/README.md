# Projet_PHP

Au final j'ai réussi a corriger les problèmes énoncés lors du petit entretien :
-Variables inconnues
-Effacement de données si l'utilisateur ne remplissait pas une case lors de modification (si la case restait vide).
-Les conditions (if) unes à unes

Problèmes que je n'ai pas pu corriger :
-Impossibilité de rentrer de guillemets dans les formulaires
-Il faut a chaque fois rafraichir la page pour que les données se mettent à jour

Ce que je n'ai pas réussi à faire :
-Changer de photo de profil
-Compte admin

Ce que qu'on peut faire en tant qu'admin :
-Modifier son profil / expérience / éducation
-Ajouter des diplômes / expériences
-Supprimer des diplômes / expériences



