<?php include("inc/header.inc.php"); ?>
<?php include("inc/data.inc.php"); ?>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top" id="sideNav">
</nav>

<?php if(!empty($_GET)) { ?>

<?php
//*********************************************** */
// Selection
$result = $pdo->query("SELECT * FROM experience WHERE Id = $_GET[id_xp];");
$xp = $result->fetch(PDO::FETCH_OBJ); ?>


<form id="form" action="" method="POST">
    <div class="form-group">
      <label for="exampleInputEmail1" class="name">Poste :</label>
      <input type="text" name="poste" id="poste" class="form-control" aria-describedby="emailHelp" value="<?php echo $xp->Poste ?>">
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Société : </label>
      <input type="text" name="societe" id="societe" class="form-control" aria-describedby="emailHelp" value="<?php echo $xp->Societe ?>">
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Date : </label>
      <input type="text" name="date" id="date" class="form-control" aria-describedby="emailHelp" value="<?php echo $xp->Dates ?>">
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Résumé : </label>
      <textarea type="text" name="resume" id="resume" class="form-control" aria-describedby="emailHelp"><?php echo $xp->Résume ?></textarea>
    </div>
    <div class="btn_ajt">
        <button type="submit" form="form" name="button" class="btn btn-light">Modifier</button>
    </div>
</form>
    
<?php } ?>

<?php
  if (!empty ($_POST)){
    $poste = $_POST['poste'];
    $societe = $_POST['societe'];
    $date = $_POST['date'];
    $resume = $_POST['resume'];
    if (!empty($poste) AND !empty($date) AND !empty($societe) AND !empty($resume)){
      $sql = "UPDATE experience SET 
      Poste = '$poste',
      Societe = '$societe',
      Dates = '$date',
      Résume = '$resume'
      where Id = $_GET[id_xp]";
      $result = $pdo->exec($sql);
      echo "Données enregistrées";
    }
    else {
      echo 'Erreur';
    }
  }
?>