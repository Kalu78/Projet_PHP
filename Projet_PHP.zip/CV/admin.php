<?php include("inc/header.inc.php"); ?>
<?php include("inc/menu2.inc.php"); ?>
<?php include("inc/data.inc.php"); ?>

<div class="container-fluid p-0">

<section class="resume-section p-3 p-lg-5 d-flex align-items-center" id="about">
  <div class="w-100">
  <?php $reponse = $pdo->query('SELECT * FROM utilisateur'); 
  while ($donnees = $reponse->fetch(PDO::FETCH_OBJ))
  {
  ?>
    <h1 class="mb-0"><?php echo $donnees->prenom ?>
      <span class="text-primary"><?php echo $donnees->nom ?></span>
    </h1>
    <div class="subheading mb-5"><?php echo $donnees->adresse . ' · ' . $donnees->ville . ' · ' . $donnees->cp . ' · '?>
      <a href="mailto:name@email.com"><?php echo $donnees->email ?></a>
    </div>
    <p class="lead mb-5"><?php echo $donnees->about ?></p>
    <div class="social-icons">
      <a href="<?php echo $donnees->linkedin ?>">
        <i class="fab fa-linkedin-in"></i>
      </a>
      <a href="<?php echo $donnees->github ?>">
        <i class="fab fa-github"></i>
      </a>
      <a href="<?php echo $donnees->twitter ?>">
        <i class="fab fa-twitter"></i>
      </a>
      <a href="<?php echo $donnees->facebook ?>">
        <i class="fab fa-facebook-f"></i>
      </a>
    </div>
    <?php } ?>
    <a href="modif_about.php">Modifier ses données personnelles</a>
  </div>
</section>

<hr class="m-0">

<a href="ajt_experience.php" class="ajt">Ajouter une expérience</a>

<section class="resume-section p-3 p-lg-5 d-flex justify-content-center" id="experience">

  <div class="w-100">
    <h2 class="mb-5">Experience</h2>
    
    <?php $reponse = $pdo->query('SELECT * FROM experience ORDER BY Dates DESC'); 
    while ($donnees = $reponse->fetch(PDO::FETCH_OBJ))
    {?>

      <div class="resume-item d-flex flex-column flex-md-row justify-content-between mb-5">
        <div class="resume-content">
          <h3 class="mb-0"><?php echo $donnees->Poste ?></h3>
          <div class="subheading mb-3"><?php echo $donnees->Societe ?></div>
          <p><?php echo $donnees->Résume ?></p>
        </div>
        <div class="resume-date text-md-right">
          <span class="text-primary"><?php echo $donnees->Dates ?></span>
        </div>
      </div>
      <a href="modif_experience.php?id_xp=<?php echo $donnees->Id; ?>" >Modifier cette expérience</a> 
      <br>
      <a href="admin.php?id_xp=<?php echo $donnees->Id; ?>">Supprimer cette expérience</a> 
      <?php if (isset($_GET["id_xp"]))
      {
        $id = $_GET["id_xp"];
        if (!empty($id))
        {
            $delete = $pdo->query("DELETE FROM experience WHERE Id=$id");
        }
      } 
    } ?>
  </div>
</section>

<hr class="m-0">

<a href="ajt_education.php" class="ajt">Ajouter un diplôme</a>

<section class="resume-section p-3 p-lg-5 d-flex align-items-center" id="education">
  <div class="w-100">
    <h2 class="mb-5">Education</h2>
      
    <?php $reponse = $pdo->query('SELECT * FROM education ORDER BY Date DESC'); 
    while ($donnees = $reponse->fetch(PDO::FETCH_OBJ))
    {?>
  
    <div class="resume-item d-flex flex-column flex-md-row justify-content-between mb-5">
      <div class="resume-content">
        <h3 class="mb-0"><?php echo $donnees->Ecole ?></h3>
        <div class="subheading mb-3"><?php echo $donnees->Diplome ?></div>
        <div><?php echo $donnees->Mention ?></div>
      </div>
      <div class="resume-date text-md-right">
        <span class="text-primary"><?php echo $donnees->Date ?></span>
      </div>
    </div>
    <a href="modif_education.php?id_educ=<?php echo $donnees->Id; ?>">Modifier ce diplôme</a>  
    <br>
    <a href="admin.php?id_educ=<?php echo $donnees->Id; ?>">Supprimer</a> 
    <?php if (isset($_GET["id_educ"]))
    {
      $id = $_GET["id_educ"];
      if (!empty($id))
      {
          $delete = $pdo->query("DELETE FROM education WHERE Id=$id");
      }
    } 
  }?>
  </div>
</section>

