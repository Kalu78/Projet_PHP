<?php include("inc/header.inc.php"); ?>
<?php include("inc/data.inc.php"); ?>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top" id="sideNav">
</nav>

<h2 class="xp">Informations personnelles</h2>
<?php $reponse = $pdo->query('SELECT * FROM utilisateur where id=1'); 
    while ($donnees = $reponse->fetch(PDO::FETCH_OBJ))
    {
    ?>
  <form id="form" action="" method="POST">
    <div class="form-group">
      <label for="exampleInputEmail1" class="name">Prenom :</label>
      <input type="text" name="prenom" id="prenom" class="form-control" aria-describedby="emailHelp" value="<?php echo $donnees->prenom ?>">
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Nom : </label>
      <input type="text" name="nom" id="nom" class="form-control" aria-describedby="emailHelp" value="<?php echo $donnees->nom ?>">
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Adresse : </label>
      <input type="text" name="adresse" id="adresse" class="form-control" aria-describedby="emailHelp" value="<?php echo $donnees->adresse ?>">
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Ville : </label>
      <input type="text" name="ville" id="ville" class="form-control" aria-describedby="emailHelp" value="<?php echo $donnees->ville ?>">
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Code postal : </label>
      <input type="text" name="cp" id="cp" class="form-control" aria-describedby="emailHelp" value="<?php echo $donnees->cp ?>">
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">E-mail : </label>
      <input type="text" name="email" id="email" class="form-control" aria-describedby="emailHelp" value="<?php echo $donnees->email ?>">
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">A propos : </label>
      <textarea type="text" name="about" id="about" class="form-control" aria-describedby="emailHelp"><?php echo $donnees->about ?></textarea>
    </div>
    
    <div class="form-group">
      <label for="exampleInputEmail1">Linkedin : </label>
      <input type="text" name="linkedin" id="linkedin" class="form-control" aria-describedby="emailHelp" value="<?php echo $donnees->linkedin ?>">
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Github : </label>
      <input type="text" name="github" id="github" class="form-control" aria-describedby="emailHelp" value="<?php echo $donnees->github ?>">
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Twitter : </label>
      <input type="text" name="twitter" id="twitter" class="form-control" aria-describedby="emailHelp" value="<?php echo $donnees->twitter ?>">
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Facebook : </label>
      <input type="text" name="facebook" id="facebook" class="form-control" aria-describedby="emailHelp" value="<?php echo $donnees->facebook ?>">
    </div>
    <div class="form-group">
            <label for="titre">Image :</label>
            <input type="file" class="form-control-file" id="img" name="img[]">
        </div>
    <div class="btn_ajt">
        <button type="submit" form="form" name="button" class="btn btn-light">Modifier</button>
    </div>
  </form>
    <?php } ?>


  <?php 
  if (!empty ($_POST)){
    $prenom = $_POST['prenom'];
    $nom = $_POST['nom'];
    $adresse = $_POST['adresse'];
    $ville = $_POST['ville'];
    $cp = $_POST['cp'];
    $email = $_POST['email'];
    $about = $_POST['about'];
    $linkedin = $_POST['linkedin'];
    $github = $_POST['github'];
    $twitter = $_POST['twitter'];
    $facebook = $_POST['facebook'];
    // $name = "";
    // if (!empty($_FILES)) {

    //     foreach ($_FILES["img"]["error"] as $key => $error) {
    //         if ($error == UPLOAD_ERR_OK) {
    //             $tmp_name = $_FILES["img"]["tmp_name"][$key];
    //             $name = basename($_FILES["img"]["name"][$key]);
    //             move_uploaded_file($tmp_name, "img/$name");
    //         }
    //     }
    // }
    // $sql = "UPDATE utilisateur SET 
    // cheminImg = 'test/$name'
    // where id=1";
    // $result = $pdo->exec($sql);


  if (!empty($prenom) AND !empty($nom) AND !empty($adresse) AND !empty($ville) AND !empty($cp) AND !empty($email) AND !empty($about) AND !empty($linkedin) AND !empty($github) AND !empty($twitter) AND !empty($facebook))
  {
    $sql = "UPDATE utilisateur SET 
    prenom = '$prenom',
    nom = '$nom',
    adresse = '$adresse',
    ville = '$ville',
    cp = '$cp',
    email = '$email',
    about = '$about',
    linkedin = '$linkedin',
    github = '$github',
    twitter = '$twitter',
    facebook = '$facebook'
    where id=1";
    $result = $pdo->exec($sql);
    echo "Données enregistrées";
  }
  else {
    echo "Erreur";
  }

}

?>

