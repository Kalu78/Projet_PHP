<?php include("inc/header.inc.php"); ?>
<?php include("inc/data.inc.php"); ?>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top" id="sideNav">
</nav>

<h2 class="xp">Education</h2>

  <form id="form" action="" method="POST">
    <div class="form-group">
      <label for="exampleInputEmail1" class="name">Ecole :</label>
      <input type="text" name="Ecole" id="Ecole" class="form-control" aria-describedby="emailHelp">
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Diplôme : </label>
      <input type="text" name="Diplome" id="Diplome" class="form-control" aria-describedby="emailHelp">
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Année(s) : </label>
      <input type="text" name="Date" id="Date" class="form-control" aria-describedby="emailHelp">
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Mention : </label>
      <textarea type="text" name="Mention" id="Mention" class="form-control" aria-describedby="emailHelp"></textarea>
    </div>
    <div class="btn_ajt">
        <button type="submit" form="form" class="btn btn-light">Ajouter</button>
    </div>
  </form>


<?php
  if (!empty ($_POST)){
    $ecole = $_POST['Ecole'];
    $diplome = $_POST['Diplome'];
    $date = $_POST['Date'];
    $mention = $_POST['Mention'];
    if (!empty($ecole) AND !empty($diplome) AND !empty($date) AND !empty($mention))
    {
      $sql = "INSERT INTO education (Ecole, Diplome, Date, Mention) VALUES ('$ecole', '$diplome', '$date', '$mention');";
      $result = $pdo->exec($sql);
      echo "Données enregistrées.";
    }
    else {
    echo "Erreur";
    }
  }
?>