<?php include("inc/header.inc.php"); ?>
<?php include("inc/data.inc.php"); ?>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top" id="sideNav">
</nav>

<?php if(!empty($_GET)) { ?>

<?php
//*********************************************** */
// Selection
$result = $pdo->query("SELECT * FROM education WHERE Id = $_GET[id_educ];");
$educ = $result->fetch(PDO::FETCH_OBJ); ?>


<form id="form" action="" method="POST">
    <div class="form-group">
      <label for="exampleInputEmail1" class="name">Ecole :</label>
      <input type="text" name="ecole" id="ecole" class="form-control" aria-describedby="emailHelp" value="<?php echo $educ->Ecole ?>">
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Diplôme : </label>
      <input type="text" name="diplome" id="diplome" class="form-control" aria-describedby="emailHelp" value="<?php echo $educ->Diplome ?>">
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Date : </label>
      <input type="text" name="date" id="date" class="form-control" aria-describedby="emailHelp" value="<?php echo $educ->Date ?>">
    </div>
    <div class="form-group">
      <label for="exampleInputEmail1">Mention : </label>
      <textarea type="text" name="mention" id="mention" class="form-control" aria-describedby="emailHelp"><?php echo $educ->Mention ?></textarea>
    </div>
    <div class="btn_ajt">
        <button type="submit" form="form" name="button" class="btn btn-light">Modifier</button>
    </div>
</form>
    
<?php } ?>

<?php
  if (!empty ($_POST)){
        $ecole = $_POST['ecole'];
        $diplome = $_POST['diplome'];
        $date = $_POST['date'];
        $mention = $_POST['mention'];
        if (!empty($ecole) AND !empty($diplome) AND !empty($date) AND !empty($mention)){
        $sql = "UPDATE education SET 
        Ecole = '$ecole',
        Diplome = '$diplome',
        Date = '$date',
        Mention = '$mention'
        where Id = $_GET[id_educ]";
        $result = $pdo->exec($sql);
        echo 'Données enregistrées';
      }
      else {
      echo 'Erreur';
    }
  }
?>