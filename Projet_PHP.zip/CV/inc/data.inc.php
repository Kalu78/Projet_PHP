<?php

$pdo = new PDO("mysql:host=localhost;dbname=cv_info", "root", "", array(PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION));

?>